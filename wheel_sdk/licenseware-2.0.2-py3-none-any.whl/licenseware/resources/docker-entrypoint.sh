#!/bin/bash
set -e

echo starting honcho
exec honcho start
