from .virtual_overview501606 import VirtualOverview501606




virtual_overview501606_component = VirtualOverview501606(
    title="Virtual Overview501606",
    component_id="virtual_overview501606",
    component_type="summary"
)

