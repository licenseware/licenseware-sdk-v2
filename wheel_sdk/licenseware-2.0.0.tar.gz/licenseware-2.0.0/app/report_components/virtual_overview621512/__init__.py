from .virtual_overview621512 import VirtualOverview621512




virtual_overview621512_component = VirtualOverview621512(
    title="Virtual Overview621512",
    component_id="virtual_overview621512",
    component_type="summary"
)

