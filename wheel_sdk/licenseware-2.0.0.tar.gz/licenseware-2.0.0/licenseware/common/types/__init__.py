"""
In this package we are creating some common types, useful for type hints

"""


from .event_type import Event