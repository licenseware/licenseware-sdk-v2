git+https://git@github.com/licenseware/licenseware-sdk-v2.git

# redis==3.5.3
# aioredis==1.3.1
# Flask==1.1.4
# flask-restx==0.5.1
# uWSGI==2.0.19.1
# marshmallow==3.12.1
# pymongo==3.12.0
# requests==2.25.1
# watchgod==0.7
# loguru==0.5.3
# ipython==7.23.1
# marshmallow-jsonschema==0.11.1
# Babel==2.9.1
# openpyxl==3.0.7
# pandas==1.2.4
# dnspython==2.1.0
# dramatiq[watch]==1.11.0
# typer==0.4.0
# pdoc3==0.10.0
# python-dotenv==0.19.0
# honcho==1.0.1

