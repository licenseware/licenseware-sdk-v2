

def create_feature(
    name:str,
    description:str = None, 
    free_quota:int = 1, 
    activated:bool = False
):
    
    """
        Return a dict with the parameters given.
        There can't be 2 features with the same `name`.
    """

    return {
        'name':name,
        'description':description,
        'free_quota':free_quota,
        'activated':activated 
    }

