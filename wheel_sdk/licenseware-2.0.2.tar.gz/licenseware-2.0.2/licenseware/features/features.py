from .create_feature import create_feature


PRODUCT_REQUESTS = create_feature(
    name="Product Requests",
    description="Allow users request products by sending emails",
    free_quota=10
)