




class UploaderCreator:

    def __init__(self, uploader_id: str):
        pass
        
