"""

Here all cli functions are gathered and decorated with typer app decorator.

"""
import os
import time
import shutil
import typer
from .utils import get_env_value, get_random_int
from .app_pkg_creator import AppPackageCreator
from .devops_creator import DevOpsCreator
from .app_root_files_creator import AppRootFilesCreator
from .uploader_creator import UploaderCreator
from .report_creator import ReportCreator
from .report_component_creator import ReportComponentCreator
from .test_creator import TestCreator



app = typer.Typer(
    name="Licenseware CLI",
    help="""
    Useful CLI commands for automatic files/folders/code creation
    """
)


@app.command()
def new_app(app_id: str):
    """ 
        Create the base package for a service 
    """
    
    AppPackageCreator.create()
    DevOpsCreator(app_id).create()
    AppRootFilesCreator(app_id).create()
    
    typer.echo("App files/folders created")


  
        
@app.command()
def new_uploader(uploader_id: str):
    """ 
        Given uploader_id build a new uploader 
        
        The package structure for the uploader will be created, imports and registration will be handled also.
    """
    
    UploaderCreator(uploader_id).create()
    typer.echo(f"Uploader `{uploader_id}` created")
    
    
@app.command()
def new_report(report_id: str):
    """ 
        Given report_id build a new report 
        
        The package structure for the report will be created, imports and registration will be handled also.
    """

    ReportCreator(report_id).create()
    typer.echo(f"Report `{report_id}` created")
    
 
    
@app.command()
def new_report_component(component_id: str, component_type: str):
    """
        Given component_id and component_type build a new report component 

        Some component types are:
        - summary
        - pie
        - bar_vertical
        - table
    
        The package structure for the report component will be created, imports and registration will be handled manually.
        
    """
    
    ReportComponentCreator(component_id, component_type).create()
    typer.echo(f"Report component `{component_id}` of type `{component_type}` created")
    
    

@app.command()
def recreate_files():
    """ Recreate files that are needed but missing  """

    app_id = get_env_value("APP_ID")
    AppPackageCreator.create()
    DevOpsCreator(app_id).create()
    AppRootFilesCreator(app_id).create()
    typer.echo("Inexisting files were recreated")



@app.command()
def build_docs():
    """
        Build app html docs
    """
    
    os.system("pdoc --html --output-dir app-docs app")
    
    timeout = 10
    count = 0
    while not os.path.exists("app-docs/app"):
        time.sleep(1)
        count += 1
        if count >= timeout:
            raise Exception("Make sure pdoc is installed and app package is available")
            
    if os.path.exists("docs"): shutil.rmtree("docs")
    shutil.move("app-docs/app", "docs")
    shutil.rmtree("app-docs")


    

@app.command()
def build_sdk_docs():
    """
        Build licenseware sdk html docs
    """
    
    os.system("pdoc --html --output-dir sdk-docs licenseware")
    
    timeout = 10
    count = 0
    while not os.path.exists("sdk-docs/licenseware"):
        time.sleep(1)
        count += 1
        if count >= timeout:
            raise Exception("Make sure pdoc is installed and licenseware package is available")
            
    if os.path.exists("docs"): shutil.rmtree("docs")
    shutil.move("sdk-docs/licenseware", "docs")
    shutil.rmtree("sdk-docs")



@app.command()
def create_tests(test_email: str = None, swagger_url: str = None):
    """ 
        Create tests from swagger docs

        Command example:
        
        >> licenseware create-tests --test-email=alin+test@licenseware.io --swagger-url=http://localhost:5000/integration/swagger.json
        
        Or

        >> licenseware create-tests

        On the second command defaults will we used

    """

    if swagger_url is None:
        base_url = get_env_value("APP_HOST")
        swagger_url = base_url + '/' + get_env_value("APP_ID") + "/swagger.json"

    if test_email is None:
        test_email = f"alin+{get_random_int()}@licenseware.io"

    typer.echo(f"Generating tests for '{test_email}' from '{swagger_url}'")

    tg = TestCreator(swagger=swagger_url, email=test_email)

    tg.generate_tests()

    typer.echo("Tests generated! Checkout `tests` folder!")