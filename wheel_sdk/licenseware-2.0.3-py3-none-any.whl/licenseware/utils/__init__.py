"""

In this package you will find various functions and classes that can be used when needed.

"""