import os
from .flask_dramatiq import Dramatiq


broker = Dramatiq(
    host=os.getenv('REDIS_HOST', 'localhost'),
    port=os.getenv('REDIS_PORT', 6379),
    db=os.getenv('REDIS_DB', 0),
    password=os.getenv('REDIS_PASSWORD', None)
)


