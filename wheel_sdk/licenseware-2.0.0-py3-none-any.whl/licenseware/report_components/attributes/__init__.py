from .bar_vertical import attributes_bar_vertical
from .pie import attributes_pie
from .summary import attributes_summary
from .table import attributes_table