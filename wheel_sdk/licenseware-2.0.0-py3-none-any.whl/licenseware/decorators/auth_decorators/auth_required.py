#TODO maybe a general auth decorator 
# which based on received paramters makes the necessary auth?