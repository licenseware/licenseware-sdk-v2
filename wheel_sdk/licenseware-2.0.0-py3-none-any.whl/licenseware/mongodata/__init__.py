from .mongodata import (
    insert, 
    fetch, 
    update,
    delete, 
    document_count, 
    delete_collection, 
    aggregate,
    get_collection,
    distinct
) 

from .mongo_connection import collection