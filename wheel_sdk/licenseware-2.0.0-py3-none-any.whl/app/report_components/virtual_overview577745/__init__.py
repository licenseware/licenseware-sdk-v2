from .virtual_overview577745 import VirtualOverview577745




virtual_overview577745_component = VirtualOverview577745(
    title="Virtual Overview577745",
    component_id="virtual_overview577745",
    component_type="summary"
)

